const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

// 각 라우트 파일을 가져옵니다
const HomeRoutes = require('./HomeRoutes');
const AuthRoutes = require('./AuthRoutes');
const AccountRoutes = require('./AccountRoutes');
const UserInfoRoutes = require('./UserInfoRoutes');
const TakeQuizRoutes = require('./TakeQuizRoutes');
const QuizResultsRoutes = require('./QuizResultsRoutes');
const WordRoutes = require('./WordRoutes');
const StaticRoutes = require('./StaticRoutes');

class App {
  constructor() {
    this.app = express();
    this.config();
    this.users = {};

    // 여기서 클래스 인스턴스화
    this.homeRoutes = new HomeRoutes(this.app);
    this.authRoutes = new AuthRoutes(this.app, this.users);
    this.accountRoutes = new AccountRoutes(this.app, this.users);
    this.userInfoRoutes = new UserInfoRoutes(this.app, this.users);
    this.takeQuizRoutes = new TakeQuizRoutes(this.app);
    this.quizResultsRoutes = new QuizResultsRoutes(this.app);
    this.wordRoutes = new WordRoutes(this.app);
    this.staticRoutes = new StaticRoutes(this.app);

    this.listen();
  }

  config() {
    this.app.use(bodyParser.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, 'public')));
  }

  listen() {
    this.app.listen(3000, () => {
      console.log('서버가 포트 3000에서 실행 중입니다');
    });
  }
}

module.exports = App;
