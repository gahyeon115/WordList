const path = require('path');

class AccountRoutes {
  constructor(app, users) {
    this.app = app;
    this.users = users;
    this.routes();
  }

  routes() {
    this.app.get('/account', (req, res) => {
      const userId = req.query.user;
      if (this.users[userId]) {
        res.sendFile(path.join(__dirname, 'views', 'account.html'));
      } else {
        res.redirect('/login');
      }
    });
  }
}

module.exports = AccountRoutes;
