const path = require('path');

class HomeRoutes {
  constructor(app) {
    this.app = app;
    this.routes();
  }

  routes() {
    this.app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, 'views', 'login.html'));
    });
  }
}

module.exports = HomeRoutes;