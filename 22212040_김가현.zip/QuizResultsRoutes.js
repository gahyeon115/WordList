class QuizResultsRoutes {
  constructor(app) {
    this.app = app;
    this.routes();
  }

  routes() {
    this.app.post('/quiz-results', (req, res) => {
      // 퀴즈 결과를 처리하는 로직 추가
      res.send('퀴즈 결과 처리');
    });
  }
}

module.exports = QuizResultsRoutes;
