const path = require('path');

class StaticRoutes {
  constructor(app) {
    this.app = app;
    this.routes();
  }

  routes() {
    this.app.get('/main', (req, res) => {
      const userId = req.query.user;
      res.sendFile(path.join(__dirname, 'views', 'main.html'));
    });
  }
}

module.exports = StaticRoutes;