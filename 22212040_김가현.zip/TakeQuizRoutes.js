const path = require('path');

class TakeQuizRoutes {
  constructor(app) {
    this.app = app;
    this.routes();
  }

  routes() {
    this.app.get('/take-quiz', (req, res) => {
      res.sendFile(path.join(__dirname, 'views', 'take-quiz.html'));
    });
  }
}

module.exports = TakeQuizRoutes;
