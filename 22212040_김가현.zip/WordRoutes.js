const path = require('path');

class WordRoutes {
  constructor(app) {
    this.app = app;
    this.routes();
  }

  routes() {
    this.app.get('/word-of-the-day', (req, res) => {
      res.sendFile(path.join(__dirname, 'views', 'word-of-the-day.html'));
    });
  }
}

module.exports = WordRoutes;