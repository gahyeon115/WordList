class UserInfoRoutes {
  constructor(app, users) {
    this.app = app;
    this.users = users;
    this.routes();
  }

  routes() {
    this.app.get('/user-info', (req, res) => {
      const userId = req.query.user;
      if (this.users[userId]) {
        res.json(this.users[userId]);
      } else {
        res.status(404).send('사용자를 찾을 수 없습니다');
      }
    });
  }
}

module.exports = UserInfoRoutes;
