const path = require('path');

class AuthRoutes {
  constructor(app, users) {
    this.app = app;
    this.users = users;
    this.routes();
  }

  routes() {
    this.app.get('/login', (req, res) => {
      res.sendFile(path.join(__dirname, 'views', 'login.html'));
    });

    this.app.post('/login', (req, res) => {
      const { id, password } = req.body;
      if (this.users[id] && this.users[id].password === password) {
        res.redirect(`/main?user=${id}`);
      } else {
        res.redirect('/login');
      }
    });

    this.app.get('/register', (req, res) => {
      res.sendFile(path.join(__dirname, 'views', 'register.html'));
    });

    this.app.post('/register', (req, res) => {
      const { id, password, name, email } = req.body;
      this.users[id] = { password, name, email, attendance: 100 };
      res.redirect('/login');
    });
  }
}

module.exports = AuthRoutes;