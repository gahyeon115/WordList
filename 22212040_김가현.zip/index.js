const App = require('./App');
new App();

